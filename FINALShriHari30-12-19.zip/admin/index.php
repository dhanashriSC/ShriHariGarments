<?php
   include("config.php");
   session_start();
   $error='';
   if($_SERVER["REQUEST_METHOD"] == "POST") {
	   $error='';
      // username and password sent from form 
      //$error='';
      $myusername = mysqli_real_escape_string($con,$_POST['username']);
      $mypassword = mysqli_real_escape_string($con,$_POST['password']); 
     
      $sql = "SELECT * FROM admin WHERE username = '$myusername' and password = '$mypassword'";
	 
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['status'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
        // session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: home.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">         
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>

</head>

<body>
	<div class="container-fluid">
	<!-- LOGIN FORM-->
	
	<div class="wrapper fadeInDown">
  <div id="formContent">
  
   <!-- Remind Passowrd -->
    <div id="formHeader">
      <a class="underlineHover" href="#">Login</a>
    </div>
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/logo.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form action = "" method = "post">
      <input type="text" id="login" class="fadeIn second" name = "username" placeholder="Username" required>
      <input type="password" id="password" class="fadeIn third" name = "password" placeholder="password" required>
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>

  </div>
</div>

	</div>
</body>
</html>
