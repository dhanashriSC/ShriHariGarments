<?php
   include('config.php');
   session_start();
   
   
   if  (isset($_SESSION['login_user'])) 
   {
	   $user_check = $_SESSION['login_user'];
	   
   $ses_sql = mysqli_query($con,"select username from admin where username = '$user_check' ")or die ('Error');
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['username'];
   }
   if(!isset($_SESSION['login_user'])){
      header("location:index.php");
      die();
   }
?>