<?Php
set_time_limit (0);
$max_file_size=2000; // This is in KB

@$todo=$_POST['todo']; // getting other form data ( optional )

$path_upload="upload/";
$path_thumbnail="upload_thumb/";

/// for thumbnail image size //
$n_width=100;
$n_height=100;
$required_image_width=890; // Width of resized image after uploading
//////////////////
while(@list($key,$value) = each($_FILES['file_up']['name']))
{
$file_name=$value;
$add = $path_upload.$file_name;   // upload directory path is set

//////////////////
// allow only jpeg or gif files, remove this if not required //
if (!($_FILES["file_up"]["type"][$key] =="image/jpeg" OR $_FILES["file_up"]["type"][$key] =="image/gif"))
{$msg=$msg."Your uploaded file must be of JPG or GIF. ";
$msg.="($file_name) Other file types are not allowed<BR>";
$file_upload_flag="false";
}else{
copy($_FILES['file_up']['tmp_name'][$key], $add);//upload the file to the server
chmod("$add",0777); // set permission to the file.


//////////ThumbNail creation //////////////////
if(file_exists($add)){
$tsrc=$path_thumbnail.$file_name; 
$im=ImageCreateFromJPEG($add); 
$width=ImageSx($im); // Original picture width is stored
$height=ImageSy($im); // Original picture height is stored
$newimage=imagecreatetruecolor($n_width,$n_height); 
imageCopyResized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
ImageJpeg($newimage,$tsrc);
chmod("$tsrc",0777);
}// end of if
////////Ending of thumb nail ////////

//// Resize original image  if width is more than 890 /////

if($required_image_width < $width){
$adjusted_height=round(($required_image_width/$width) * $height);
//echo $adjusted_height . " - ".$height."<br>";
$im=ImageCreateFromJPEG($add); 
$newimage=imagecreatetruecolor($required_image_width,$adjusted_height); 
imageCopyResized($newimage,$im,0,0,0,0,$required_image_width,$adjusted_height,$width,$height);
ImageJpeg($newimage,$add);
chmod("$add",0777);
} // end of if width of image  is more 

/// Display inside IFrame ( check upload.php file )///

echo " &nbsp; <a href='$add' target='new'><img src='$tsrc'></a>";
} // if file type is image 
} // while loop for all files

echo "<br>$msg";
?>