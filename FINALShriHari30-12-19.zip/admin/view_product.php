<?php
   include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">         
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>

</head>

<body>
	<div class="container-fluid">
	<!-- Header Section-->
		<div class="container-fluid fixed-top">
			<div class="container">
				<div class="row">
					<div class="col-md-2">
						<a href="home.php"><img src="images/logo.png" class="img-responsive logo-img"></a>
					</div>
					<div class="col-md-8">
						<!--<h2 class="head-title">Online Shopping</h2>-->
						 <nav>
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
							  <a class="nav-item nav-link"  href="#nav-home"><b>HOME</b></a>
							  <a class="nav-item nav-link " href="#nav-profile" >VIEW PRODUCTS</a>
							  <a class="nav-item nav-link active" href="#nav-contact" >UPLOAD PRODUCTS</a>
							  
							</div>
						  </nav>
					</div>
					<div class="col-md-1"></div>
					<div class="col-md-1">
						<p><a href = "index.php" class="signout">Sign Out</a></p>
					</div>
				</div>
				<div class="row products-sec">
				</div>
			</div>
		</div>
	</div>
</body>
</html>