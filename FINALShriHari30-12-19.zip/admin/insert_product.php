<?php

if (isset($_POST['submit'])) 
{
	$pname = mysqli_real_escape_string($con,$_POST['name']);
    $prate = mysqli_real_escape_string($con,$_POST['rate']);
    $pdesc = mysqli_real_escape_string($con,$_POST['desc']);
	
	/*$pname='Dummy';
	$prate='100';
	$pdesc='trial desc';*/
	
	$j = 0;     // Variable for indexing uploaded image.
	$target_path = "uploads/";     // Declaring Path for uploaded images.
	$tot=count($_FILES['file']['name']);
	
	//Insert Query
				$sql = "INSERT INTO `products`( `name`, `rate`, `description`, `created_date`, `status`) VALUES ('".$pname."','".$prate."','".$pdesc."',NOW(),1)";
				
				$result = mysqli_query($con,$sql);
				$pid=mysqli_insert_id($con);
	
	for ($i = 0; $i < count($_FILES['file']['name']); $i++) 
	{
		$filename=basename($_FILES['file']['name'][$i]);
		
		// Loop to get individual element from the array
		$validextensions = array("jpeg", "jpg", "png");      // Extensions which are allowed.
		$ext = explode('.', basename($_FILES['file']['name'][$i]));   // Explode file name from dot(.)
		$file_extension = end($ext); // Store extensions in the variable.
		//$target_path = $target_path . md5(uniqid()) . "." . $ext[count($ext) - 1];     // Set the target path with a new name of image.
		$j = $j + 1;      // Increment the number of uploaded images according to the files in array.
		$finalpath=$target_path.$filename;
		if (in_array($file_extension, $validextensions)) 
		{
			
			if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $finalpath))
			{
				// If file moved to uploads folder.
				//echo $j. ').<span id="noerror">Image uploaded successfully!.</span><br/><br/>';
					
				
				$sql1="INSERT INTO `product_imgs`(`image_name`, `image_path`, `product_id`, `status`) VALUES ('".$filename."','".$finalpath."',$pid,1)";
				echo $sql1;
				$result1 = mysqli_query($con,$sql1);
				
			} 
			else {     //  If File Was Not Moved.
				echo $j. ').<span id="error">please try again!.</span><br/><br/>';
			}
		} else {     //   If File Size And File Type Was Incorrect.
		echo $j. ').<span id="error">***Invalid file Size or Type***</span><br/><br/>';
		}
	}

	
}
?>
