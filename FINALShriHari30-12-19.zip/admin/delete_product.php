<?php
include 'config.php';

			$pid=$_POST['row_id'];

			$sql="UPDATE `products` SET `status`=0 WHERE `product_id`= $pid";
					
			$result = mysqli_query($con,$sql);
					
			if(! $result ) {
				die('Could not get data: ' . mysql_error());
			}
?>