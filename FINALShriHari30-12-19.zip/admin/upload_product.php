<?php
   include('session.php');
   $error='';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">         
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>
	<script language="Javascript" src="js/jquery.dataTables.min.js"></script>
	<script language="Javascript" src="js/multi-upload.js"></script>
	<style>
	nav > div a.nav-item.nav-link.active:after{
		    right: 68px !important;
			    left: -70px;
	}
	</style>
</head>

<body>
	<div class="container-fluid main">
	<!-- Header Section-->
		<div class="container-fluid fixed-top">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2">
						<a href="home.php"><img src="images/logo.png" class="img-responsive logo-img"></a>
					</div>
					<div class="col-md-6">
						<!--<h2 class="head-title">Online Shopping</h2>-->
						 <nav>
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
							  <a class="nav-item nav-link"  href="home.php"><b>HOME</b></a>
							  <a class="nav-item nav-link " href="view_products.php" >VIEW PRODUCTS</a>
							  <a class="nav-item nav-link active" href="upload_product.php" >UPLOAD PRODUCTS</a>
							  
							</div>
						  </nav>
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-1">
						<p><a href = "index.php" class="signout">Sign Out</a></p>
					</div>
				</div>
			</div>
		</div>
			<div class="container-fluid main-content">
				<div class="row products-sec">
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<h2>Multiple Image Upload Form</h2>
						<form enctype="multipart/form-data" action="" method="post">
						
							<input type="text" id="name" class="fadeIn second" name = "name" placeholder="Name" required>
								<input type="text" id="rate" class="fadeIn third" name = "rate" placeholder="Rate" required>
								<textarea type="text" id="desc" class="fadeIn fourth" name = "desc" placeholder="Description" required></textarea>
								<div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
									
								<div id="filediv"><input name="file[]" type="file" id="file"/></div>
								<input type="button" id="add_more" class="upload" value="Add More Files"/>
								<input type="submit" value="Upload" name="submit" id="upload" class="upload"/>
						</form>
				</div>
				<div class="col-md-3"></div>
				</div>
				<!--<div class="row products-sec">
					<div class="col-md-5">
						<div class="wrapper fadeInDown">
						  <div id="formContent">
							<div id="formHeader">
							  <a class="underlineHover" href="#">Upload Product</a>
							</div>
								<form enctype="multipart/form-data" action = "" method = "post">
									<input type="text" id="name" class="fadeIn second" name = "name" placeholder="Name" required>
									<input type="text" id="rate" class="fadeIn third" name = "rate" placeholder="Rate" required>
									<textarea type="text" id="desc" class="fadeIn fourth" name = "desc" placeholder="Description" required></textarea>
									<div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
							</div>
						</div>
					</div>
					<div class="col-md-7">
						<div class="wrapper fadeInDown">
							<div id="filediv"><input name="file[]" type="file" id="file" class="fadeIn fifth"  placeholder="Face Image" required></div>
							<input type="button" id="add_more" class="upload admore-btn" value="Add More Files"/>
							<input type="submit" name="submit"  id="upload"  class="fadeIn fourth" value="Upload" style="width:20px;padding-left: 25px;">
							
							</form>
							<?php include "insert_product.php"; ?>
						</div>
					</div>
				</div>-->
			</div>
		</div>
	</div>
	<script>
	$(document).ready(function() {
		$('#example').DataTable();
	} );
	</script>
</body>
</html>