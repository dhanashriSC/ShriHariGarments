<?php
   include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">         
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>
	<script language="Javascript" src="js/jquery.dataTables.min.js"></script>
	<style>
	nav > div a.nav-item.nav-link.active:after{
		    right: 68px !important;
			    left: -70px;
	}
	</style>
</head>

<body>
	<div class="container-fluid main">
	<!-- Header Section-->
		<div class="container-fluid fixed-top">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2">
						<a href="home.php"><img src="images/logo.png" class="img-responsive logo-img"></a>
					</div>
					<div class="col-md-6">
						<!--<h2 class="head-title">Online Shopping</h2>-->
						 <nav>
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
							  <a class="nav-item nav-link"  href="home.php"><b>HOME</b></a>
							  <a class="nav-item nav-link active" href="view_products.php" >VIEW PRODUCTS</a>
							  <a class="nav-item nav-link " href="upload_product.php" >UPLOAD PRODUCTS</a>
							  
							</div>
						  </nav>
					</div>
					<div class="col-md-3"></div>
					<div class="col-md-1">
						<p><a href = "index.php" class="signout">Sign Out</a></p>
					</div>
				</div>
			</div>
		</div>
		<div class="container-fluid main-content">
				<div class="row products-sec">
					<div class="col-md-1">
					
					</div>
					<div class="col-md-10">
						<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Sr No.</th>
									<th>Product Name</th>
									<th>Rate</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php 
					
								$sql="SELECT `product_id`,`name`,`rate`,`description`,`created_date` FROM `products` WHERE `status`=1";
								
								$result = mysqli_query($con,$sql);
								
								if(! $result ) {
									die('Could not get data: ' . mysql_error());
								}
								if (mysqli_num_rows($result) > 0) {
									$counter = 0;
									while($row = mysqli_fetch_assoc($result)) {
							?>
								<tr>
									<td><?php echo ++$counter; ?></td>
									<td><?php echo $row['name'];?></td>
									<td><?php echo $row['rate'];?></td>
									<td>
										<img src="images/x.png" class="remove" id="<?php echo $row['product_id']?>" alt="Remove Product" style="cursor:pointer;height:20px;width:20px"/>
									</td>
								</tr>
								<?php 
								}
					 } else {
						echo "0 results";
					 }
								?>
							</tbody>
						</table>
					</div>
					<div class="col-md-1">
					
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
	$(document).ready(function() {
		$('#example').DataTable();
		$('.remove').click(function(){
			var id = $(this).attr('id');
			 //$(this).closest('tr').remove()
				let tr =  $(this).parent().parent(); //Define the TR itself

				$.post('delete_product.php', {row_id:  id}, function(result){
				  //Do something with the message your page returns after deleting
				  tr.remove(); //Remove the TR from the dom
				  alert('Product Deleted Successfully!');
				});
		});
	} );
	</script>
</body>
</html>