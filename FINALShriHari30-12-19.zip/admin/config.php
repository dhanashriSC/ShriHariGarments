<?php
/*   define('DB_SERVER', 'localhost:81');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'shriharidb');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   echo "connected....";*/
?>

<?php
//all the variables defined here are accessible in all the files that include this one
$con= new mysqli('localhost','root','','shriharidb')or die("Could not connect to mysql".mysqli_error($con));

?>