<?php
   include('admin/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">         
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>

</head>

<body>
	<div class="container-fluid main">
	<!-- Header Section-->
		<div class="container-fluid fixed-top ">
			<div class="container">
				<div class="row">
					<div class="col-md-1">
						<a href="index.php"><img src="images/logo.png" class="img-responsive logo-img"></a>
					</div>
					<div class="col-md-7">
						<h2 class="head-title">Online Shopping</h2>
					</div>
					<div class="col-md-3">	
					</div>
				</div>
			</div>
		</div>
			<div class="container mid-content">
				<div class="row products-sec">
				<?php 
					
					$sql="SELECT `product_id`,`name`,`rate`,`description`,`created_date` FROM `products` WHERE `status`=1";
					
					$result = mysqli_query($con,$sql);
					
					if(! $result ) {
						die('Could not get data: ' . mysql_error());
					}
					if (mysqli_num_rows($result) > 0) {
						while($row = mysqli_fetch_assoc($result)) {
							
							$desc = $row['description'];
							if( strlen( $desc) > 20) {
								$str = explode( "\n", wordwrap( $desc, 20));
								$str = $str[0] . '...';
							}				
							
							$pid=$row['product_id'];
							
							$sql1="SELECT `image_id`, `image_name`, `image_path`, `product_id`, `status` FROM `product_imgs` WHERE `product_id`=$pid and `status`=1 LIMIT 1";
					
							$result1 = mysqli_query($con,$sql1);
							
							if(! $result1 ) {
								die('Could not get data: ' . mysql_error());
							}
							if (mysqli_num_rows($result1) > 0) {
								while($row1 = mysqli_fetch_assoc($result1)) {
						
				?>
					<div class="col-md-3">
					<a href="product_details.php?product_id=<?=$pid?>">
						<div>
					<img src="admin/uploads/<?php echo $row1['image_name'];?>" class="img-responsive product-img zoom">
						<div class="prod-desc detail">
							<h5><?php echo $row['name'];?></h5>	
							<p><?php echo $str;?></p>
							<p class="prod-price"><?php echo $row['rate'];?></p>
						</div>
						</div>
					</a>
					</div>
				<?php
				
								}
							}
					}
					 } else {
						echo "0 results";
					 }
   
					mysqli_close($con);
				?>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
