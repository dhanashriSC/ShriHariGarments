<?php 
include 'admin/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Shrihari Garments</title>
    <!-- base href="http://www.shriharigarments.in/" -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/drift-basic.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/thumbelina.css">
	<!-- Scripts-->
	<script language="Javascript" src="js/jquery-3.4.1.min.js"></script>
	<script language="Javascript" src="js/bootstrap.js"></script>
	<script language="Javascript" src="js/bootstrap.min.js"></script>
</head>

<body>
	
	<!-- Header Section-->
				<div class="container-fluid fixed-top ">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-1">
						<a href="index.php"><img src="images/logo.png" class="img-responsive logo-img"></a>
					</div>
					<div class="col-md-7">
						<h2 class="head-title">Online Shopping</h2>
					</div>
					<div class="col-md-3">	
					</div>
				</div>
			</div>
		</div>
			<div class="container-fluid mid-content">
				<div class="row">
					<a href="index.php"><b style="margin-left:15px;">Back</b></a>
				</div>
				<div class="row products-sec">
					<div class="col-md-1">
							<div id="thumbnails">
							  <div class="thumbelina-but vert top">&#708;</div>
							  <ul>
				<?php
							$pid=$_GET['product_id'];
							$sql1="SELECT `image_id`, `image_name`, `image_path`, `product_id`, `status` FROM `product_imgs` WHERE `product_id`=$pid and `status`=1";
					
							$result1 = mysqli_query($con,$sql1);
							
							if(! $result1 ) {
								die('Could not get data: ' . mysql_error());
							}
							if (mysqli_num_rows($result1) > 0) {
								
								while($row1 = mysqli_fetch_assoc($result1)) {
									?>
						
								<li>
								  <a href="admin/uploads/<?php echo $row1['image_name'];?>" title="View"><!-- Large Image-->
									<img class="cloudzoom-gallery"
										 src="admin/uploads/<?php echo $row1['image_name'];?>"
										 alt="thumbnail"
										 data-cloudzoom="
										   useZoom:'.cloudzoom',
										   image:'admin/uploads/<?php echo $row1['image_name'];?>'
										 ">
								   </a>
								</li>
					<?php 
						}
							}
					?>								
							  </ul>
							  <div class="thumbelina-but vert bottom">&#709;</div>
							</div>
					</div>
					
					<div class="col-md-4 imgdiv" id="product-image">
					<?php 
							$pid=$_GET['product_id'];
							$sql2="SELECT `image_id`, `image_name`, `image_path`, `product_id`, `status` FROM `product_imgs` WHERE `product_id`=$pid and `status`=1 LIMIT 1";
					
							$result2 = mysqli_query($con,$sql2);
							
							if(! $result2 ) {
								die('Could not get data: ' . mysql_error());
							}
							if (mysqli_num_rows($result2) > 0) {	
							
								while($row2 = mysqli_fetch_assoc($result2)) {
					?>
						<!-- <div class="demo-area">
							<img class="cloudzoom img-responsive demo-trigger" src="images/products/1_006.jpg?w=200&ch=DPR&dpr=2&border=1,ddd" data-zoom="images/products/1_006.jpg?w=1000&ch=DPR&dpr=2">
						</div> -->
						 <a href="admin/uploads/<?php echo $row2['image_name'];?>">
							<img class="cloudzoom"
								 src="admin/uploads/<?php echo $row2['image_name'];?>"
								 alt=""
								 data-cloudzoom="
								   zoomPosition:'inside',
								   zoomOffsetX:0,
								   zoomFlyOut:false,
								   variableMagnification:false,
								   disableZoom:'auto',
								   touchStartDelay:100,
								   propagateGalleryEvent:true
								 ">
						  </a>
					</div>
					<?php 
						}
								}
					?>
					<div class="col-md-7 prod-det detail">
					<?php 
					
							$pid=$_GET['product_id'];
							
							$sql="SELECT `product_id`,`name`,`rate`,`description`,`created_date` FROM `products` WHERE `status`=1 and `product_id`=$pid";
					
							$result = mysqli_query($con,$sql);
							
							if(! $result ) {
								die('Could not get data: ' . mysql_error());
							}
							if (mysqli_num_rows($result) > 0) {
								
								while($row = mysqli_fetch_assoc($result)) {
					
					?>
						<h4 class="prod-title"><?php echo $row["name"];?></h4>
						<h4 class="prod-title">Description</h4>
						<p>
							<?php echo $row["description"];?>
						</p>
						<p><b>Rs. <?php echo $row["rate"];?> </b></p>
						<h4>Please call or whats app us on the number 9881090200 to purchase / enquiry the product</h4>
					</div>
					<?php
					}
					 } else {
						echo "0 results";
					 }
   
					mysqli_close($con);
				?>
				</div>
			</div>
		</div>
	
</body>
 <script src='js/Drift.min.js'></script>
 <script>
	var demoTrigger = document.querySelector('.demo-trigger');
var paneContainer = document.querySelector('.detail');

new Drift(demoTrigger, {
  paneContainer: paneContainer,
  inlinePane: false,
});
 </script>
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js'></script>
 <script src='js/thumbelina.js'></script>
 <script src='js/sliderjs.js'></script>
</html>